import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="mb-8">
          <Link href="/">
            <h1 className="text-2xl font-bold text-center">
              <span className="text-primary">Content</span>Hub
            </h1>
          </Link>
          <p className="text-center text-foreground/60 mt-2">Sign in to your account</p>
        </div>

        <form className="space-y-6 bg-card border border-border rounded-lg p-8">
          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <Input type="email" placeholder="you@example.com" required />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <Input type="password" placeholder="••••••••" required />
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded border-border" />
              Remember me
            </label>
            <Link href="#" className="text-primary hover:text-primary/80">
              Forgot password?
            </Link>
          </div>

          <Button className="w-full" size="lg">
            Sign In
          </Button>
        </form>

        <p className="text-center text-foreground/60 mt-6">
          Don&apos;t have an account?{' '}
          <Link href="/signup" className="text-primary hover:text-primary/80">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  )
}
