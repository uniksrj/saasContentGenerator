import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

const activityData = [
  { date: 'Mon', articles: 4, topics: 2 },
  { date: 'Tue', articles: 6, topics: 3 },
  { date: 'Wed', articles: 5, topics: 4 },
  { date: 'Thu', articles: 8, topics: 5 },
  { date: 'Fri', articles: 12, topics: 6 },
  { date: 'Sat', articles: 3, topics: 2 },
  { date: 'Sun', articles: 7, topics: 4 },
]

const usageData = [
  { name: 'Articles', used: 245, limit: 5000, percentage: 4 },
  { name: 'Topics', used: 89, limit: 1000, percentage: 8 },
  { name: 'Projects', used: 5, limit: 100, percentage: 5 },
]

export default function DashboardPage() {
  return (
    <main className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/20 rounded-lg p-8">
        <h1 className="text-3xl font-bold mb-2">Welcome back, John</h1>
        <p className="text-foreground/70">You&apos;re on the Pro plan. Here&apos;s your activity this week.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'Articles', value: '245', change: '+12 this week' },
          { label: 'Topics', value: '89', change: '+5 this week' },
          { label: 'Projects', value: '5', change: '+1 this week' },
          { label: 'Collaborators', value: '8', change: '+2 this month' },
        ].map((stat, i) => (
          <Card key={i} className="bg-card border border-border p-6">
            <p className="text-foreground/60 text-sm mb-2">{stat.label}</p>
            <p className="text-3xl font-bold mb-2">{stat.value}</p>
            <p className="text-foreground/50 text-sm">{stat.change}</p>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="bg-card border border-border p-6">
          <h2 className="text-xl font-semibold mb-4">Activity This Week</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" stroke="#888" />
              <YAxis stroke="#888" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1a1a1a',
                  border: '1px solid #333',
                  borderRadius: '0.5rem',
                }}
              />
              <Line
                type="monotone"
                dataKey="articles"
                stroke="var(--color-primary)"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="topics"
                stroke="var(--color-chart-2)"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="bg-card border border-border p-6">
          <h2 className="text-xl font-semibold mb-4">Usage Limits</h2>
          <div className="space-y-6">
            {usageData.map((item, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium">{item.name}</p>
                  <p className="text-sm text-foreground/60">
                    {item.used}/{item.limit}
                  </p>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Items */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Recent Articles</h2>
            <Button variant="ghost" size="sm">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {[
              { title: 'Getting Started with AI', date: 'Today', status: 'Published' },
              { title: 'Content Strategy 2026', date: 'Yesterday', status: 'Draft' },
              { title: 'Marketing Automation Guide', date: '2 days ago', status: 'Review' },
            ].map((article, i) => (
              <div
                key={i}
                className="p-3 rounded-lg bg-secondary/50 hover:bg-secondary/70 transition cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">{article.title}</h3>
                  <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">
                    {article.status}
                  </span>
                </div>
                <p className="text-sm text-foreground/60 mt-1">{article.date}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Quick Actions</h2>
          </div>
          <div className="space-y-3">
            <Button className="w-full justify-start" variant="outline">
              + Create New Project
            </Button>
            <Button className="w-full justify-start" variant="outline">
              + Add Topic
            </Button>
            <Button className="w-full justify-start" variant="outline">
              + Draft Article
            </Button>
            <Button className="w-full justify-start" variant="outline">
              + Invite Team Member
            </Button>
          </div>
        </Card>
      </div>
    </main>
  )
}
