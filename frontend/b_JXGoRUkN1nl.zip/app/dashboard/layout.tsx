import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Settings, LogOut, Plus, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
        <div className="p-6 border-b border-sidebar-border">
          <Link href="/">
            <h1 className="text-xl font-bold">
              <span className="text-primary">Content</span>Hub
            </h1>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <Link
            href="/dashboard"
            className="block px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition"
          >
            Dashboard
          </Link>
          <Link
            href="/dashboard/projects"
            className="block px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition"
          >
            Projects
          </Link>
          <Link
            href="/dashboard/topics"
            className="block px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition"
          >
            Topics
          </Link>
          <Link
            href="/dashboard/articles"
            className="block px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition"
          >
            Articles
          </Link>
          <Link
            href="/dashboard/billing"
            className="block px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition"
          >
            Billing
          </Link>
        </nav>

        <div className="p-4 border-t border-sidebar-border space-y-2">
          <Link href="/dashboard/settings" className="flex items-center gap-2 px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition">
            <Settings size={18} />
            Settings
          </Link>
          <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent/10 transition">
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <div className="flex-1 max-w-xl">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground/40" size={18} />
              <Input
                placeholder="Search projects, topics, articles..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button size="sm" className="gap-2">
              <Plus size={18} />
              New
            </Button>
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
              JD
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </div>
    </div>
  )
}
