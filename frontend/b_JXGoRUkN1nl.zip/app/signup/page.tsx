import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function SignupPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="mb-8">
          <Link href="/">
            <h1 className="text-2xl font-bold text-center">
              <span className="text-primary">Content</span>Hub
            </h1>
          </Link>
          <p className="text-center text-foreground/60 mt-2">Create your account</p>
        </div>

        <form className="space-y-6 bg-card border border-border rounded-lg p-8">
          <div>
            <label className="block text-sm font-medium mb-2">Full Name</label>
            <Input type="text" placeholder="John Doe" required />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <Input type="email" placeholder="you@example.com" required />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <Input type="password" placeholder="••••••••" required />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Confirm Password</label>
            <Input type="password" placeholder="••••••••" required />
          </div>

          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-1" required />
            <span>
              I agree to the{' '}
              <Link href="#" className="text-primary hover:text-primary/80">
                Terms of Service
              </Link>{' '}
              and{' '}
              <Link href="#" className="text-primary hover:text-primary/80">
                Privacy Policy
              </Link>
            </span>
          </label>

          <Button className="w-full" size="lg">
            Create Account
          </Button>
        </form>

        <p className="text-center text-foreground/60 mt-6">
          Already have an account?{' '}
          <Link href="/login" className="text-primary hover:text-primary/80">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
